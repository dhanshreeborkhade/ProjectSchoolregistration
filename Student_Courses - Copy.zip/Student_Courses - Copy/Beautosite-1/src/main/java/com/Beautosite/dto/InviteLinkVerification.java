package com.Beautosite.dto;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class InviteLinkVerification {
	private ResponseVe response;
	private String UUID;
}