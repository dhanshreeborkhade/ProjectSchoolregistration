package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.entity.SunshineShop;

@Repository
public interface ShopRepository extends JpaRepository<SunshineShop, Long> {
	
	
	@Query("SELECT a FROM SunshineShop a WHERE a.email=:email" )
	public SunshineShop finbyemail(String email);

}
