package com.service;

import java.util.List;
import java.util.Optional;

import com.entity.SunshineShop;

public interface ShopService {
	  
	
   public  SunshineShop addShopRecords(SunshineShop shop);
   
   public Optional<SunshineShop>  getShopRecordsbyid(Long shop1);
   
   public List<SunshineShop> getallshoprecords();
   
   
   public void deleterecordsbyid(Long id);
   
   public void deleteallrecords();
}
