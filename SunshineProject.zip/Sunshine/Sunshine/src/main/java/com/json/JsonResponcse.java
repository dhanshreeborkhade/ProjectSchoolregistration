package com.json;

import lombok.Data;


public class JsonResponcse {
	
	private String Status;
	private String Result;
	private String Message;
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public String getResult() {
		return Result;
	}
	public void setResult(String result) {
		Result = result;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	@Override
	public String toString() {
		return "JsonResponcse [Status=" + Status + ", Result=" + Result + ", Message=" + Message + "]";
	}
	public JsonResponcse(String status, String result, String message) {
		super();
		Status = status;
		Result = result;
		Message = message;
	}
	public JsonResponcse() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
