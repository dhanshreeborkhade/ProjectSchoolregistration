package com.myController;

import java.util.List;
import java.util.Optional;

import org.hibernate.engine.spi.Resolution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.SunshineShop;
import com.json.JsonResponcse;
import com.service.ShopService;
import com.serviceimpl.ShopServiceImpl;

@RestController
@RequestMapping("/shop")
public class ShopController {
	@Autowired

	private ShopServiceImpl shopservice;

	// create shop data
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public JsonResponcse addreocrds(@RequestBody SunshineShop shop) {

		JsonResponcse responce = new JsonResponcse();

		SunshineShop shopdata = shopservice.byemail(shop.getEmail());

		if (shopdata == null) {

			shopservice.addShopRecords(shop);
			responce.setStatus("200OK");
			responce.setResult("Success");
			responce.setMessage("Shop Regsiter Succesfully !! With id=" + shop.getShopid());
		} else {
			responce.setStatus("300OK");
			responce.setResult("USuccess");
			responce.setMessage("This ShopName is Already Regsiter  kindly Create  Another Email.!!");
		}

		return responce;

	}

	// Get by id
	@GetMapping("/getshop/{id}")
	public JsonResponcse getShop(@PathVariable Long id) {
		JsonResponcse responce = new JsonResponcse();

		Optional<SunshineShop> ids = shopservice.getShopRecordsbyid(id);

		if (ids.isPresent()) {
			responce.setMessage(ids.get().toString());
			responce.setResult("Success..");
			responce.setStatus("200");
		} else {
			responce.setMessage("Id Is Not Present!!");
			responce.setResult("Unsucces");
			responce.setStatus("404");
		}

		return responce;
	}

//Get shop by Id
	@GetMapping("/getone/{id}")
	public SunshineShop getShopById(@PathVariable Long id) {

		Optional<SunshineShop> data = shopservice.getShopRecordsbyid(id);

		if (data.isPresent()) {
			return data.get();
		}
		throw new RuntimeException("Data not present" + id);
	}

	// Delete data byID
	@DeleteMapping("/delete/{id}")
	public JsonResponcse getdeletebyid(@PathVariable Long id) {
		JsonResponcse responce = new JsonResponcse();

		Optional<SunshineShop> shopdelete = shopservice.getShopRecordsbyid(id);
		if (shopdelete.isPresent()) {
			shopservice.deleterecordsbyid(id);
			responce.setStatus("200OK");
			responce.setResult("Success");
			responce.setMessage("Shop Deleted  Succesfully !!");
		} else {
			responce.setStatus("300OK");
			responce.setResult("UnSuccess");
			responce.setMessage("Shop Not Present In Data  !!");
		}

		return responce;

	}

	// Delete all records
	@DeleteMapping("/deleteall")
	public JsonResponcse deleteAll() {
		JsonResponcse responce = new JsonResponcse();
		try {

			shopservice.deleteallrecords();
			responce.setStatus("200OK");
			responce.setResult("Success");
			responce.setMessage(" All Shop Records Deleted  Succesfully !!");

		} catch (Exception ex) {
			responce.setStatus("400OK");
			responce.setResult("UnSuccessful");
			responce.setMessage("Something went Wrong Data Not Found !!");
			System.out.println(ex.getMessage());

		}

		return responce;
	}

	// Update shop records

	@PutMapping("/updatedata/{id}")
	public JsonResponcse updatedata(@RequestBody SunshineShop shop, @PathVariable Long id) {
		JsonResponcse responce = new JsonResponcse();
		Optional<SunshineShop> ids = shopservice.getShopRecordsbyid(id);

		if (ids.isPresent()) {

			SunshineShop shopupdate = ids.get();

			shopupdate.setCity(shop.getCity());
			shopupdate.setEmail(shop.getEmail());
			shopupdate.setPassword(shop.getPassword());
			shopupdate.setShopOwnerName(shop.getShopOwnerName());
			shopupdate.setShopid(shop.getShopid());

			shopservice.addShopRecords(shop);
			responce.setMessage("Data updated Sucessfully with id=" +shop.getShopid());
			responce.setStatus("200OK");
			responce.setResult("Success");
		} else {
			responce.setStatus("400OK");
			responce.setResult("UnSuccessful");
			responce.setMessage("id is not present!!");
		}

		return responce;
	}

	
	//Get all Records
	
	@GetMapping("/getall")
	 public List<SunshineShop> getall(){
		
		List<SunshineShop> getshoplist =  shopservice.getallshoprecords();
		return getshoplist;
	}
	
}
