package com.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="Sunshine_Data")
public class SunshineShop {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long shopid;
	private String ShopOwnerName;
	private String email;
	private String City;
	private String password;
	
	
	public long getShopid() {
		return shopid;
	}
	public void setShopid(long shopid) {
		this.shopid = shopid;
	}
	public String getShopOwnerName() {
		return ShopOwnerName;
	}
	public void setShopOwnerName(String shopOwnerName) {
		ShopOwnerName = shopOwnerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "SunshineShop [shopid=" + shopid + ", ShopOwnerName=" + ShopOwnerName + ", email=" + email + ", City="
				+ City + ", password=" + password + "]";
	}
	public SunshineShop(long shopid, String shopOwnerName, String email, String city, String password) {
		super();
		this.shopid = shopid;
		ShopOwnerName = shopOwnerName;
		email = email;
		City = city;
		this.password = password;
	}
	public SunshineShop() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
	

}
