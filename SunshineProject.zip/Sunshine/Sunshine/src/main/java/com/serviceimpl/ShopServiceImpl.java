package com.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.SunshineShop;
import com.repository.ShopRepository;
import com.service.ShopService;

@Service
public class ShopServiceImpl implements ShopService{

	@Autowired
	private ShopRepository shoprepo;
	
	@Override
	public SunshineShop addShopRecords(SunshineShop shop) {
		return shoprepo.save(shop);
		 
	}

	@Override
	public Optional<SunshineShop> getShopRecordsbyid(Long shop1) {
		return shoprepo.findById(shop1);
		
	}
	

	@Override
	public List<SunshineShop> getallshoprecords() {
		
		return shoprepo.findAll();
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleterecordsbyid(Long id) {
		
		 shoprepo.deleteById(id);
			
	}

	@Override
	public void deleteallrecords() {
		 
		  shoprepo.deleteAll();
	}
	
	
	public SunshineShop byemail(String email)
	{
		return shoprepo.finbyemail(email);
	}
	
	
       
}
